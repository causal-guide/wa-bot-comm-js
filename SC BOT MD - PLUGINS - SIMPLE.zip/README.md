# azamibot-md-multi

<a href="https://github.com/clicknetcafe/azamibot-md-multi/network/members"><img title="Forks" src="https://img.shields.io/github/forks/clicknetcafe/azamibot-md-multi?label=Forks&color=blue&style=flat-square"></a>
<a href="https://github.com/clicknetcafe/azamibot-md-multi/watchers"><img title="Watchers" src="https://img.shields.io/github/watchers/clicknetcafe/azamibot-md-multi?label=Watchers&color=green&style=flat-square"></a>
<a href="https://github.com/clicknetcafe/azamibot-md-multi/stargazers"><img title="Stars" src="https://img.shields.io/github/stars/clicknetcafe/azamibot-md-multi?label=Stars&color=yellow&style=flat-square"></a>
<a href="https://github.com/clicknetcafe/azamibot-md-multi/graphs/contributors"><img title="Contributors" src="https://img.shields.io/github/contributors/clicknetcafe/azamibot-md-multi?label=Contributors&color=blue&style=flat-square"></a>
<a href="https://github.com/clicknetcafe/azamibot-md-multi/issues"><img title="Issues" src="https://img.shields.io/github/issues/clicknetcafe/azamibot-md-multi?label=Issues&color=success&style=flat-square"></a>
<a href="https://github.com/clicknetcafe/azamibot-md-multi/issues?q=is%3Aissue+is%3Aclosed"><img title="Issues" src="https://img.shields.io/github/issues-closed/clicknetcafe/azamibot-md-multi?label=Issues&color=red&style=flat-square"></a>
<a href="https://github.com/clicknetcafe/azamibot-md-multi/pulls"><img title="Pull Request" src="https://img.shields.io/github/issues-pr/clicknetcafe/azamibot-md-multi?label=PullRequest&color=success&style=flat-square"></a>
<a href="https://github.com/clicknetcafe/azamibot-md-multi/pulls?q=is%3Apr+is%3Aclosed"><img title="Pull Request" src="https://img.shields.io/github/issues-pr-closed/clicknetcafe/azamibot-md-multi?label=PullRequest&color=red&style=flat-square"></a>


<!-- This Script is for everyone, original base by [`BochilGaming`](https://github.com/BochilGaming/games-wabot-md)

<p align="center">
      <img src="https://i.ibb.co/DR4vjVN/nother.jpg" width="55%" style="margin-left: auto;margin-right: auto;display: block;">
</p>

If you want to add Node Modules manually, download here : [`node_modules`](https://cutt.ly/zeren-node-modules)

This is Script of WhatsApp multi device, working with [`@whiskeysockets/baileys`](https://github.com/whiskeysockets/baileys) -->

## Join Group Minimalist ツ Sweet
[![Grup WhatsApp](https://img.shields.io/badge/WhatsApp%20Group-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://chat.whatsapp.com/JoX2bndasBq2DzSPMuN6vD)
**MAX BOT : 4**

## Run

```bash
node .
```

---------

## Arguments `node . [--options] [<session name>]`
### `Contoh: node . --pairing`

### `--pairing`
Link device via pairing

### `--mobile`
Link device via mobile captcha (blm tes, rawan ban katanya)

### `--self`
Mode self (gak ada yang bisa gunakan, kecuali nomor bot dan owner)

### `--pconly`
Bot cuma bisa dipakai di Private Chat (kecuali user premium)

### `--gconly`
Bot cuma bisa dipakai di Grup (kecuali user premium)

### `--swonly`
bot cuma respon dari status

### `--server`
Untuk [heroku](https://heroku.com/) atau scan lewat website

### `--restrict`
Enables restricted plugins (which can lead your number to be **banned** if used too often)

* Group Administration `add, kick`

### `--img`
Enable image inspector through terminal

### `--autoread`
Autoread pesan

### `--autocleartmp`
If enabled, **tmp* folder contain files will be auto delete

### `--nyimak`
Bot nyimak doang, nampilin pesan di console dan add user ke database

### `--test`
**Development** Testing Mode

### `--db`
pass mongodb url or cloud url to connect to database, by the default it will connect to database.json

---------

### Cara set Nomor Owner ?

> Via command: .addrealowner saat bot berjalan, atau set dalam file `config.js`, di global.mods..
```js
global.mods = ['6282337245566']
```
> Contoh nomor `6282337245566`, bisa add lebih dari 1

---------

#### Original Base From :
[![BochilGaming](https://github.com/BochilGaming.png?size=100)](https://github.com/BochilGaming)